package com.carddang.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.carddang.dao.CarddangDAO;
import com.carddang.dao.UserVO;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		response.setContentType("text/html;charset=euc-kr");		
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String pw2 = request.getParameter("pw2");
		String car = request.getParameter("car");
		double distance = Double.parseDouble(request.getParameter("dis"));
		
		UserVO user = new UserVO(id, pw, car, distance);
		CarddangDAO dao = new CarddangDAO();
		int result = dao.signUp(user);
		
		if(result > 0) {
			response.sendRedirect("Main.jsp");
		}else {
			response.sendRedirect("Fail.html");
		}
	}



}
