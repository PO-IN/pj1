package com.carddang.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carddang.dao.CarddangDAO;
import com.carddang.dao.UserVO;

/**
 * Servlet implementation class distance
 */
@WebServlet("/distance")
public class distance extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double dis = Double.parseDouble(request.getParameter("dis"));
		HttpSession session = request.getSession();
		UserVO user = (UserVO) session.getAttribute("user");
		
		CarddangDAO dao = new CarddangDAO();
		int result = dao.newDistance(user.getPhone(), dis);
		if(result > 0) {
			response.sendRedirect("List.jsp");
		}
	}

}
