package com.carddang.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carddang.dao.CarddangDAO;
import com.carddang.dao.RecordVO;
import com.carddang.dao.UserVO;

/**
 * Servlet implementation class Record
 */
@WebServlet("/Record")
public class Record extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		response.setContentType("text/html;charset=euc-kr");
		
		HttpSession session = request.getSession();
		UserVO user = (UserVO) session.getAttribute("user");
		String id = user.getPhone();
		String dowhat = request.getParameter("dowhat");
		String dowhen = request.getParameter("dowhen");
		int money = Integer.parseInt(request.getParameter("money"));
		String content = request.getParameter("content");
		
		RecordVO record = new RecordVO(id, dowhat, money, content, dowhen);
		CarddangDAO dao = new CarddangDAO();
		int result = dao.addRecord(record);
		
		if(result > 0) {
			response.sendRedirect("Record.jsp");
		}
	}

}
