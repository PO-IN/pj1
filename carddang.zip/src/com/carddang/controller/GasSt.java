package com.carddang.controller;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.carddang.dao.TopTenVO;

public class GasSt {
	public TopTenVO[] topTen(String gas) throws Exception {
		URL url = new URL("http://www.opinet.co.kr/api/lowTop10.do?out=xml&code=F219171106&prodcd=" + gas + "&area=16");
		URLConnection connection = url.openConnection();

		Document doc = parseXML(connection.getInputStream());
		NodeList descNodes = doc.getElementsByTagName("OIL");
		TopTenVO[] result = new TopTenVO[10];
		for (int i = 0; i < descNodes.getLength(); i++) {
			TopTenVO topten = null;
			String uni_id = null;
			String price = null;
			String name = null;
			String address = null;
			for (Node node = descNodes.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {

				if (node.getNodeName().equals("UNI_ID")) {
					uni_id = node.getTextContent();
				} else if (node.getNodeName().equals("PRICE")) {
					price = node.getTextContent();
				} else if (node.getNodeName().equals("POLL_DIV_CO")) {

				} else if (node.getNodeName().equals("OS_NM")) {
					name = node.getTextContent();
				} else if (node.getNodeName().equals("NEW_ADR")) {
					address = node.getTextContent();
				} else if (node.getNodeName().equals("GIS_X_COOR")) {

				} else if (node.getNodeName().equals("GIS_Y_COOR")) {

				}
				topten = new TopTenVO(uni_id, name, price, address);
				result[i] = topten;
			}
		}
		return result;
	}

	private Document parseXML(InputStream stream) throws Exception {

		DocumentBuilderFactory objDocumentBuilderFactory = null;
		DocumentBuilder objDocumentBuilder = null;
		Document doc = null;

		try {

			objDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
			objDocumentBuilder = objDocumentBuilderFactory.newDocumentBuilder();

			doc = objDocumentBuilder.parse(stream);

		} catch (Exception ex) {
			throw ex;
		}

		return doc;
	}
}
