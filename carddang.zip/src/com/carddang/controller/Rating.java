package com.carddang.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carddang.dao.CarddangDAO;
import com.carddang.dao.UserVO;

/**
 * Servlet implementation class Rating
 */
@WebServlet("/Rating")
public class Rating extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		response.setContentType("text/html;charset=euc-kr");	
		
		String garage = request.getParameter("garage");
		HttpSession session = request.getSession();
		UserVO user = (UserVO) session.getAttribute("user");
		String id = user.getPhone();
		int a = Integer.parseInt(request.getParameter("a"));
		int b = Integer.parseInt(request.getParameter("b"));
		int c = Integer.parseInt(request.getParameter("c"));
		int d = Integer.parseInt(request.getParameter("d"));
		int e = Integer.parseInt(request.getParameter("e"));	
		
		
		CarddangDAO dao = new CarddangDAO();
		int result = dao.doRate(id, garage, a, b, c, d, e);
		if(result >0) {
			response.sendRedirect("Garage.jsp");
		}
	}

}
