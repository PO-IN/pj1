package com.carddang.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CarddangDAO {
	String dburl = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	String dbid = "dj";
	String dbpw = "123456";

	Connection conn = null;
	PreparedStatement pst = null;

	public int signUp(UserVO user) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("insert into carddang_user values(?, ?, ?, ?)");
			pst.setString(1, user.getPhone());
			pst.setString(2, user.getPw());
			pst.setString(3, user.getCar());
			pst.setDouble(4, user.getDistance());
			result = pst.executeUpdate();

			PreparedStatement pst2 = conn
					.prepareStatement("insert into carddang_list values(?,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
			pst2.setString(1, user.getPhone());
			pst2.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ResultSet login(String id, String pw) {
		ResultSet result = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("select * from carddang_user where phone = ? and password = ?");
			pst.setString(1, id);
			pst.setString(2, pw);
			result = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public int addRecord(RecordVO record) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("insert into carddang_record values(?, ?, ?, ?, ?)");
			pst.setString(1, record.getId());
			pst.setString(2, record.getDowhat());
			pst.setInt(3, record.getMoney());
			pst.setString(4, record.getContent());
			pst.setString(5, record.getDowhen());
			result = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ResultSet getRecord(String id) {
		ResultSet result = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("select * from carddang_record where phone = ? order by dowhen desc");
			pst.setString(1, id);
			result = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public int getMoney(String id) throws SQLException {
		int result = 0;
		ResultSet result2 = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement(
					"select money from carddang_record where phone = ? and (dowhen > trunc(sysdate, 'mm'))");
			pst.setString(1, id);
			result2 = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while (result2.next()) {
			result += result2.getInt(1);
		}

		return result;
	}

	public int deleteRecord(String id, String b, String c) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("delete carddang_record where phone = ? and dowhen = ? and money =?");
			pst.setString(1, id);

			pst.setString(2, b);
			pst.setInt(3, Integer.parseInt(c));
			result = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public ResultSet getRecord2(String id, String what) {
		ResultSet result = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement(
					"select money, dowhen from carddang_record where phone = ? and dowhat = ? and (dowhen > trunc(sysdate, 'yyyy'))");
			pst.setString(1, id);
			pst.setString(2, what);
			result = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public ResultSet getGarage() {
		ResultSet result = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("select * from carddang_garage");
			result = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public int doRate(String id, String garage, int a, int b, int c, int d, int f) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("insert into carddang_rating values(?, ?, ?, ?, ?, ?, ?)");
			pst.setString(1, id);
			pst.setString(2, garage);
			pst.setInt(3, a);
			pst.setInt(4, b);
			pst.setInt(5, c);
			pst.setInt(6, d);
			pst.setInt(7, f);

			result = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}

	public int setComp(String id, String comp, double distance) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("update carddang_list set " + comp + " =? where phone = ?");
			pst.setDouble(1, distance);
			pst.setString(2, id);

			result = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public ResultSet getList(String id) {
		ResultSet result = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("select * from carddang_list where phone = ?");
			pst.setString(1, id);
			result = pst.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public int[] getRating(String name) {
		ResultSet result = null;

		int[] rating = new int[5];
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement(
					"select sum(col1), sum(col2), sum(col3), sum(col4), sum(col5) from carddang_rating where name = ?");
			pst.setString(1, name);

			result = pst.executeQuery();

			PreparedStatement pst2 = conn.prepareStatement("select * from carddang_rating where name = ?");
			pst2.setString(1, name);
			int total = pst2.executeUpdate();
			if (result.next()) {
				rating[0] = result.getInt(1) / total;
				rating[1] = result.getInt(2) / total;
				rating[2] = result.getInt(3) / total;
				rating[3] = result.getInt(4) / total;
				rating[4] = result.getInt(5) / total;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rating;
	}

	public int newDistance(String id, double dis) {
		int result = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("update carddang_user set distance = ? where phone = ?");
			pst.setDouble(1, dis);
			pst.setString(2, id);

			result = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public double getDis(String id) {
		ResultSet result = null;
		double result2 = 0;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dburl, dbid, dbpw);
			pst = conn.prepareStatement("select distance from carddang_user where phone = ?");
			pst.setString(1, id);

			result = pst.executeQuery();
			if (result.next()) {
				result2 = result.getDouble(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result2;
	}
}
