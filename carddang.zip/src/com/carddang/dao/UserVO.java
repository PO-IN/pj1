package com.carddang.dao;

public class UserVO {
	private String phone;
	private String pw;
	private String car;
	private double distance;
	
	public UserVO(String phone, String pw, String car, double distance) {
		this.phone = phone;
		this.pw = pw;
		this.car = car;
		this.distance = distance;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	
	
	
}
