package com.carddang.dao;

public class RecordVO {
	private String id;
	private String dowhat;
	private String dowhen;
	private int money;
	private String content;
	
	public RecordVO(String id, String dowhat, int money, String content, String dowhen) {
		super();
		this.id = id;
		this.dowhat = dowhat;
		this.dowhen = dowhen;
		this.money = money;
		this.content = content;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDowhat() {
		return dowhat;
	}

	public void setDowhat(String dowhat) {
		this.dowhat = dowhat;
	}

	public String getDowhen() {
		return dowhen;
	}

	public void setDowhen(String dowhen) {
		this.dowhen = dowhen;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	
}
